import { Component } from '@angular/core';
import {AlertController, NavController} from 'ionic-angular';
import { Storage } from '@ionic/storage';
import { RegistroPage } from '../registro/registro';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  registro = RegistroPage;

  constructor(public navCtrl: NavController, public alertCtrl: AlertController, public storage: Storage ) {

  }
 
clickRegistro(){
  this.navCtrl.push (this.registro)
}
}
